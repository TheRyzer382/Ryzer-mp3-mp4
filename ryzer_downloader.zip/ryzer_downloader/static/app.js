const form = document.querySelector("#downloadForm");
const formatInputs = [...document.querySelectorAll('input[name="format"]')];
const quality = document.querySelector("#quality");
const statusBox = document.querySelector("#status");
const resultBox = document.querySelector("#downloadResult");
const submitBtn = document.querySelector("#submitBtn");
const historySection = document.querySelector("#historySection");

function syncQuality() {
  const fmt = formatInputs.find(x => x.checked)?.value || "mp3";
  quality.innerHTML = fmt === "mp3"
    ? '<option value="192">MP3 · 192 kbps</option><option value="128">MP3 · 128 kbps</option><option value="320">MP3 · 320 kbps</option>'
    : '<option value="source">Kaynak kalite</option><option value="720">720p</option><option value="480">480p</option>';
}
formatInputs.forEach(x => x.addEventListener("change", syncQuality));
syncQuality();

function showStatus(message, type="") {
  statusBox.hidden = false;
  statusBox.className = "status " + type;
  statusBox.textContent = message;
}
function formatBytes(n) {
  if (!n) return "—";
  const units = ["B","KB","MB","GB"]; let i=0, v=n;
  while (v>=1024 && i<units.length-1) {v/=1024;i++;}
  return `${v.toFixed(i ? 1 : 0)} ${units[i]}`;
}
form.addEventListener("submit", async e => {
  e.preventDefault();
  resultBox.hidden = true; resultBox.replaceChildren();
  submitBtn.disabled = true; submitBtn.textContent = "İşleniyor…";
  showStatus("Kaynak indiriliyor ve çıktı hazırlanıyor. Dosya boyutuna göre biraz sürebilir.");
  const body = {
    url: document.querySelector("#url").value.trim(),
    format: formatInputs.find(x => x.checked).value,
    quality: quality.value
  };
  try {
    const res = await fetch("/api/download", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "İşlem başarısız.");
    showStatus(`Hazır! Dosya boyutu: ${formatBytes(data.bytes)}.`, "success");
    const a = document.createElement("a");
    a.className = "result-link"; a.href = data.download_url; a.textContent = "Dosyayı indir ↓";
    resultBox.appendChild(a); resultBox.hidden = false;
    await loadHistory();
  } catch(err) {
    showStatus(err.message || "Beklenmeyen bir hata oluştu.", "error");
    await loadHistory();
  } finally {
    submitBtn.disabled = false; submitBtn.innerHTML = 'Hazırla <span>↗</span>';
  }
});

async function loadHistory() {
  const list = document.querySelector("#historyList");
  try {
    const res = await fetch("/api/history");
    const data = await res.json();
    if (!data.items.length) { list.innerHTML = '<p class="hint">Henüz işlem yok.</p>'; return; }
    list.replaceChildren();
    data.items.forEach(item => {
      const row = document.createElement("div"); row.className = "history-item";
      const info = document.createElement("div");
      const title = document.createElement("b");
      title.textContent = `${item.format.toUpperCase()} · ${item.status === "completed" ? "Tamamlandı" : "Başarısız"}`;
      const meta = document.createElement("small");
      meta.textContent = `${new Date(item.created_at).toLocaleString("tr-TR")} · ${formatBytes(item.bytes)} · ${item.quality} · ${item.status === "failed" ? item.error : item.source_url}`;
      info.append(title, meta); row.append(info);
      if (item.download_url) {
        const a = document.createElement("a"); a.href = item.download_url; a.textContent = "İndir ↓"; row.append(a);
      }
      list.append(row);
    });
  } catch { list.textContent = "Geçmiş şu anda yüklenemiyor."; }
}
document.querySelector("#historyToggle").addEventListener("click", async () => {
  historySection.hidden = !historySection.hidden;
  if (!historySection.hidden) { await loadHistory(); historySection.scrollIntoView({behavior:"smooth",block:"start"}); }
});
document.querySelector("#clearHistory").addEventListener("click", async () => {
  if (!confirm("İndirme geçmişi silinsin mi? Dosyalar silinmez.")) return;
  await fetch("/api/history", {method:"DELETE"}); await loadHistory();
});
