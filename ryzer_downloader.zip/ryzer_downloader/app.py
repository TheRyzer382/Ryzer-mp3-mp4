import os, re, json, time, uuid, socket, ipaddress, sqlite3, subprocess, tempfile
from urllib.parse import urlparse, urljoin
from pathlib import Path
from datetime import datetime, timezone
import requests
from flask import Flask, request, jsonify, send_file, send_from_directory

ROOT = Path(__file__).resolve().parent
DOWNLOAD_DIR = Path(os.environ.get("DOWNLOAD_DIR", ROOT / "downloads")).resolve()
DB_PATH = Path(os.environ.get("DB_PATH", ROOT / "history.sqlite3")).resolve()
MAX_BYTES = int(os.environ.get("MAX_DOWNLOAD_BYTES", str(500 * 1024 * 1024)))
CONNECT_TIMEOUT = int(os.environ.get("CONNECT_TIMEOUT", "15"))
READ_TIMEOUT = int(os.environ.get("READ_TIMEOUT", "45"))
ALLOWED_HOSTS = {h.strip().lower() for h in os.environ.get("ALLOWED_HOSTS", "").split(",") if h.strip()}
app = Flask(__name__, static_folder="static")
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            source_url TEXT NOT NULL,
            filename TEXT NOT NULL,
            format TEXT NOT NULL,
            quality TEXT NOT NULL,
            bytes INTEGER NOT NULL,
            status TEXT NOT NULL,
            error TEXT
        )""")
init_db()

def validate_url(url):
    if not isinstance(url, str) or len(url) > 4096:
        raise ValueError("Geçerli bir medya URL'si gir.")
    p = urlparse(url.strip())
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Yalnızca http:// veya https:// ile başlayan doğrudan medya bağlantıları desteklenir.")
    host = p.hostname.lower().rstrip(".")
    if host in ("localhost",) or host.endswith(".localhost") or host.endswith(".local"):
        raise ValueError("Yerel ağ adreslerine izin verilmiyor.")
    if ALLOWED_HOSTS and host not in ALLOWED_HOSTS:
        raise ValueError("Bu sunucuda yalnızca izin verilen alan adları kullanılabilir.")
    try:
        infos = socket.getaddrinfo(host, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)
        ips = {info[4][0].split("%")[0] for info in infos}
    except socket.gaierror:
        raise ValueError("Alan adı çözümlenemedi.")
    if not ips:
        raise ValueError("Alan adı için IP bulunamadı.")
    for ip in ips:
        addr = ipaddress.ip_address(ip)
        if not addr.is_global:
            raise ValueError("Güvenlik nedeniyle özel/yerel IP adreslerine izin verilmiyor.")
    return url.strip()

def safe_get(url):
    current = validate_url(url)
    session = requests.Session()
    session.headers.update({"User-Agent": "RyzerDownloader/1.0"})
    for _ in range(6):
        # Redirects are handled manually so each target is validated.
        r = session.get(current, stream=True, allow_redirects=False,
                        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
        if r.is_redirect or r.is_permanent_redirect:
            loc = r.headers.get("Location")
            r.close()
            if not loc:
                raise ValueError("Kaynak geçersiz yönlendirme döndürdü.")
            current = validate_url(urljoin(current, loc))
            continue
        if r.status_code < 200 or r.status_code >= 300:
            status = r.status_code
            r.close()
            raise ValueError(f"Kaynak sunucu HTTP {status} döndürdü.")
        return r
    raise ValueError("Çok fazla yönlendirme var.")

def run_ffmpeg(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=60*60)
    except FileNotFoundError:
        raise RuntimeError("FFmpeg bulunamadı. Docker ile çalıştır veya README'deki kurulum adımını uygula.")
    except subprocess.TimeoutExpired:
        raise RuntimeError("Dönüştürme zaman aşımına uğradı.")
    if p.returncode != 0:
        detail = (p.stderr or "Bilinmeyen FFmpeg hatası")[-1200:]
        raise RuntimeError("Medya dönüştürülemedi: " + detail)

def download_source(url, path):
    r = safe_get(url)
    content_type = (r.headers.get("Content-Type") or "").lower()
    length = r.headers.get("Content-Length")
    if length and length.isdigit() and int(length) > MAX_BYTES:
        r.close()
        raise ValueError(f"Dosya boyutu sınırı aşıyor (en fazla {MAX_BYTES // (1024*1024)} MB).")
    total = 0
    try:
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024*256):
                if not chunk:
                    continue
                total += len(chunk)
                if total > MAX_BYTES:
                    raise ValueError(f"Dosya boyutu sınırı aşıyor (en fazla {MAX_BYTES // (1024*1024)} MB).")
                f.write(chunk)
    finally:
        r.close()
    if total == 0:
        raise ValueError("Kaynak boş bir dosya döndürdü.")
    # Reject obvious HTML pages; direct media URLs only.
    with open(path, "rb") as f:
        head = f.read(512).lstrip().lower()
    if "text/html" in content_type or head.startswith(b"<!doctype html") or head.startswith(b"<html"):
        raise ValueError("Bu bir medya dosyası değil, web sayfası. Doğrudan MP3/MP4 medya URL'si gir.")
    return total

@app.get("/")
def index():
    return send_from_directory(ROOT / "static", "index.html")

@app.get("/api/health")
def health():
    try:
        ffmpeg_ok = subprocess.run(["ffmpeg", "-version"], capture_output=True, timeout=5).returncode == 0
    except (FileNotFoundError, subprocess.SubprocessError):
        ffmpeg_ok = False
    return jsonify({"ok": True, "service": "Ryzer Downloader", "ffmpeg": ffmpeg_ok})

@app.get("/api/history")
def history():
    with db() as c:
        rows = c.execute("SELECT * FROM history ORDER BY id DESC LIMIT 100").fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["download_url"] = f"/files/{item['filename']}" if item["status"] == "completed" else None
        items.append(item)
    return jsonify({"items": items})

@app.delete("/api/history")
def clear_history():
    with db() as c:
        c.execute("DELETE FROM history")
    return jsonify({"ok": True})

@app.get("/files/<path:filename>")
def get_file(filename):
    # No nested paths or hidden files.
    if filename != os.path.basename(filename) or filename.startswith("."):
        return jsonify({"error": "Geçersiz dosya adı"}), 400
    target = (DOWNLOAD_DIR / filename).resolve()
    if target.parent != DOWNLOAD_DIR or not target.is_file():
        return jsonify({"error": "Dosya bulunamadı"}), 404
    return send_file(target, as_attachment=True, download_name=filename)

@app.post("/api/download")
def download():
    data = request.get_json(silent=True) or {}
    url = data.get("url", "").strip()
    fmt = data.get("format", "mp3").lower()
    quality = str(data.get("quality", "192"))
    if fmt not in ("mp3", "mp4"):
        return jsonify({"error": "Format MP3 veya MP4 olmalı."}), 400
    if fmt == "mp3" and quality not in ("128", "192", "320"):
        return jsonify({"error": "MP3 kalitesi 128, 192 veya 320 kbps olmalı."}), 400
    if fmt == "mp4" and quality not in ("source", "720", "480"):
        return jsonify({"error": "MP4 kalitesi Kaynak, 720p veya 480p olmalı."}), 400

    source_tmp = None
    out_path = None
    row_id = None
    try:
        url = validate_url(url)
        fd, source_tmp = tempfile.mkstemp(prefix="ryzer_src_")
        os.close(fd)
        source_size = download_source(url, source_tmp)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_name = f"ryzer_{stamp}_{uuid.uuid4().hex[:8]}.{fmt}"
        out_path = (DOWNLOAD_DIR / out_name).resolve()
        if fmt == "mp3":
            run_ffmpeg(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", source_tmp,
                        "-vn", "-codec:a", "libmp3lame", "-b:a", f"{quality}k", "-ar", "44100",
                        str(out_path)])
        elif quality == "source":
            # Remux to MP4; re-encode only if source codecs/container need it.
            p = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", source_tmp,
                                "-c", "copy", "-movflags", "+faststart", str(out_path)],
                               capture_output=True, text=True, timeout=60*60)
            if p.returncode != 0:
                run_ffmpeg(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", source_tmp,
                            "-c:v", "libx264", "-preset", "veryfast", "-c:a", "aac",
                            "-movflags", "+faststart", str(out_path)])
        else:
            run_ffmpeg(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", source_tmp,
                        "-vf", f"scale=-2:'min({quality},ih)'", "-c:v", "libx264",
                        "-preset", "veryfast", "-crf", "23", "-c:a", "aac",
                        "-movflags", "+faststart", str(out_path)])
        if not out_path.exists() or out_path.stat().st_size == 0:
            raise RuntimeError("Çıktı dosyası oluşturulamadı.")
        size = out_path.stat().st_size
        with db() as c:
            cur = c.execute("INSERT INTO history (created_at,source_url,filename,format,quality,bytes,status,error) VALUES (?,?,?,?,?,?,?,?)",
                (datetime.now(timezone.utc).isoformat(), url, out_name, fmt, quality, size, "completed", None))
            row_id = cur.lastrowid
        return jsonify({"ok": True, "id": row_id, "filename": out_name,
                        "bytes": size, "download_url": f"/files/{out_name}",
                        "format": fmt, "quality": quality})
    except (ValueError, RuntimeError, requests.RequestException, OSError, subprocess.SubprocessError) as e:
        msg = str(e)[:1500]
        with db() as c:
            c.execute("INSERT INTO history (created_at,source_url,filename,format,quality,bytes,status,error) VALUES (?,?,?,?,?,?,?,?)",
                (datetime.now(timezone.utc).isoformat(), url[:4096], "", fmt, quality, 0, "failed", msg))
        return jsonify({"error": msg}), 400
    finally:
        if source_tmp and os.path.exists(source_tmp):
            try: os.remove(source_tmp)
            except OSError: pass

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")), debug=False)
