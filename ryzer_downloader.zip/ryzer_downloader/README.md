# Ryzer Downloader

Siyah-gri arayüzlü, doğrudan medya URL'leri için Flask + FFmpeg tabanlı MP3/MP4 dönüştürücü/indirici.

## Neler var?

- Doğrudan HTTP(S) medya URL'sinden indirme
- MP3 çıktısı: 128 / 192 / 320 kbps
- MP4 çıktısı: kaynak kalite / 720p / 480p
- SQLite indirme geçmişi ve geçmişteki dosyaları yeniden indirme
- Android/tablet uyumlu responsive arayüz
- URL doğrulama, yönlendirmeleri tek tek kontrol etme, özel IP engeli, indirme boyutu sınırı
- Docker ile FFmpeg dahil kurulum

> Yalnızca erişim ve indirme hakkına sahip olduğun içeriklerde kullan. Bu araç YouTube/TikTok/Instagram gibi platform sayfalarını ayrıştırmaz; doğrudan medya URL'si gerekir. Kalite seçenekleri kaynağın sunmadığı bir kaliteyi geri getirmez; düşük kaliteye dönüştürebilir.

## Hızlı kurulum (önerilen: Docker)

Gereksinim: Docker ve Docker Compose.

```bash
docker compose up --build -d
```

Sonra tarayıcıdan `http://localhost:8080` adresini aç. Başka cihazlardan aynı ağ üzerinden erişmek için `localhost` yerine sunucu bilgisayarının yerel IP'sini kullan.

Loglar:
```bash
docker compose logs -f
```

Durdur:
```bash
docker compose down
```

İndirme dosyaları `./downloads`, geçmiş veritabanı uygulama dizininde `history.sqlite3` olarak tutulur. Docker kullanırken veritabanını da kalıcılaştırmak istersen `docker-compose.yml` içindeki `volumes` bölümüne `./data:/app/data` ekle ve `DB_PATH: /app/data/history.sqlite3` ortam değişkenini tanımla.

## Docker olmadan

- Python 3.11+
- FFmpeg (komut satırında `ffmpeg -version` çalışmalı)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Ardından `http://localhost:8080`.

## API

### `GET /api/health`
Servis ve FFmpeg durumunu verir.

### `POST /api/download`
JSON gövdesi:
```json
{"url":"https://cdn.example.org/video.mp4","format":"mp3","quality":"192"}
```
`format`: `mp3` veya `mp4`. MP3 kalitesi `128`, `192`, `320`; MP4 kalitesi `source`, `720`, `480`.

Başarılı cevap:
```json
{"ok":true,"id":1,"filename":"ryzer_...mp3","bytes":12345,"download_url":"/files/ryzer_...mp3","format":"mp3","quality":"192"}
```

### `GET /api/history`
Son 100 işlem.

### `DELETE /api/history`
Geçmiş kayıtlarını siler; dosyaları silmez.

### `GET /files/<filename>`
Oluşturulan dosyayı indirir.

## Dağıtım ve güvenlik notları

- İnternete açık dağıtım için HTTPS/TLS, kimlik doğrulama, hız sınırı ve saklama/temizleme politikası ekle.
- Varsayılan 500 MB sınırı `MAX_DOWNLOAD_BYTES` ile değiştirilebilir.
- İsteğe bağlı `ALLOWED_HOSTS` değişkeniyle kaynak alan adlarını virgülle ayırarak izin listesi oluştur.
- Bu demo çok kullanıcılı bir SaaS için tasarlanmamıştır; geçmiş ortak SQLite veritabanında görünür. Herkese açık dağıtımdan önce kullanıcı oturumu ve kullanıcı başına geçmiş/dosya izolasyonu ekle.
- Büyük dosyalar ve eşzamanlı dönüştürmeler sunucu CPU/disk kullanımını artırır. Üretimde kuyruk, kota, zaman aşımı ve otomatik dosya temizleme kullan.
